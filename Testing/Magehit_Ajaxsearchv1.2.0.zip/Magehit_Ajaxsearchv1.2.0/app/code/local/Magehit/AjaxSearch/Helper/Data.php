<?php
/* <!-- AjaxSearch --> */
class Magehit_AjaxSearch_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}
<?php
class Kanavan_Searchautocomplete_SuggestController extends Mage_Core_Controller_Front_Action
{
    public function resultAction()
    {

		$this->loadLayout();     
		$this->renderLayout();

    }
}
